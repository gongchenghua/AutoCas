Run the code

# generate information cascades
python gene_cas.py --input=./dataset/weibo/

# generate cascade graph and global graph embeddings 
python gene_emb.py --input=./dataset/weibo/

# run AutoCas model
python main.py --input=./dataset/weibo/