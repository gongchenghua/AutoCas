import torch
import torch.nn as nn
from transformers.models.gpt2.modeling_gpt2 import GPT2Model
from transformers import GPT2Tokenizer
from layers.mlp import MLP

device = torch.device("cuda:7")

class Model(nn.Module):
    def __init__(self, configs):
        super(Model, self).__init__()
        self.token_len = configs.token_len      
        self.gpt2 = GPT2Model.from_pretrained(configs.llm_ckp_dir) 
        self.tokenizer = GPT2Tokenizer.from_pretrained(configs.llm_ckp_dir)
        self.tokenizer.pad_token = self.tokenizer.eos_token
        self.hidden_dim_of_gpt2 = 768
        self.max_len = configs.max_seq
        
        for name, param in self.gpt2.named_parameters():
            param.requires_grad = False

        self.encoder = MLP(self.token_len, self.hidden_dim_of_gpt2, 
                            configs.mlp_hidden_dim, configs.mlp_hidden_layers, 
                            configs.dropout, configs.mlp_activation)
        self.decoder = MLP(self.hidden_dim_of_gpt2, self.token_len,
                            configs.mlp_hidden_dim, configs.mlp_hidden_layers,
                            configs.dropout, configs.mlp_activation) 
        self.pred_head = MLP(self.token_len, 1,
                            configs.mlp_hidden_dim, configs.mlp_hidden_layers,
                            configs.dropout, configs.mlp_activation)
    
    def get_prompt_embedding(self, prompt_text, batch_size):
        if isinstance(prompt_text, str):
            prompt_text = [prompt_text] * batch_size
        inputs = self.tokenizer(prompt_text,
                                 return_tensors="pt",
                                 padding=True,
                                 truncation=True,
                                 max_length=self.max_len).to(device)
        with torch.no_grad():
            prompt_embeds = self.gpt2.get_input_embeddings()(inputs["input_ids"].to(device)).to(device)
            attention_mask = inputs["attention_mask"].to(device)
            prompt_embeds = (prompt_embeds * attention_mask.unsqueeze(-1)).sum(dim=1) / attention_mask.sum(dim=1, keepdim=True)
            
        return prompt_embeds
    
    def forecast(self, x_enc, x_mark_enc, prompt):  # [B,23,40000]
        # print("input to gpt2") 
        B, N, _ = x_enc.shape 
        embeds = self.encoder(x_enc) # [B,N,768]

        prompt_embeds = self.get_prompt_embedding(prompt, batch_size = B)  # [B,768]
        # print(prompt_embeds.shape)
        prompt_embeds = prompt_embeds.unsqueeze(1).expand(-1, N, -1) # [B,N,768]

        combined_embeds = embeds + prompt_embeds
        outputs = self.gpt2(
            inputs_embeds = combined_embeds).last_hidden_state
        dec_out = self.decoder(outputs) # [B,23,40000]
        # print("dec_out shape",dec_out.shape)
        llm_output = dec_out.reshape(B,N,self.max_len,-1) # [B,23,500,80]
        # print('llm_output', llm_output.shape)

        pop = self.pred_head(dec_out) # [B,23,1]
        # print('pop', pop.shape)
        pop = pop.reshape(B,N) # [B,23]
    
        return llm_output, pop
    
    def forward(self, x_enc, x_mark_enc, prompt):
        return self.forecast(x_enc, x_mark_enc, prompt)