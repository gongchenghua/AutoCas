import argparse

"""
Dataset | Observation Time           | Prediction Time               |
---------------------------------------------------------------------|
weibo   | 3600 (1 hour)              | 3600*24 (86400, 1 day)        |
twitter | 3600*24*1 (172800, 2 days) | 3600*24*32 (2764800, 32 days) |
aps     | 365*3 (1095, 3 years)      | 365*20+5 (7305, 20 years)     |
"""

parser = argparse.ArgumentParser()
######################  dataset path
parser.add_argument('--input', default='./dataset/weibo/', type=str, help="Dataset path.")
parser.add_argument('--gg_path', default='global_graph.pkl', type=str, help="Global graph path.")
######################gene_cas
parser.add_argument("--observation_time", type=int, default=3600, help="Observation time.")
parser.add_argument("--prediction_time", type=int, default=3600*24, help="Prediction time.")

######################gene_emb
parser.add_argument("--cg_emb_dim", type=int, default=40, help="Cascade graph embedding dimension.")
parser.add_argument("--gg_emb_dim", type=int, default=40, help="Global graph embedding dimension.")
parser.add_argument("--max_seq", type=int, default=500, help="Max length of cascade sequence.") # weibo:500 twitter:400 aps:200
parser.add_argument("--num_s", type=int, default=2, help="Number of s for spectral graph wavelets.")

######################model
parser.add_argument("--lr", type= float, default=4*5e-4, help="Learning rate.") # 原始4*5e-4
parser.add_argument("--b_size", type=int, default=256, help="Batch size.") # gpt2:256 twitter_prompt:128
parser.add_argument("--emb_dim", type=int, default=40+40, help="Embedding dimension (cascade emb_dim + global emb_dim")
parser.add_argument("--z_dim", type=int, default=64, help="Dimension of latent variable z.")
parser.add_argument("--rnn_units", type=int, default=128, help="Dimension of latent variable z.")
parser.add_argument("--n_flows", type=int, default=8, help="Number of NF transformations.")
parser.add_argument("--verbose", type=int, default=2, help="Verbose.")
parser.add_argument("--patience", type=int, default=10, help="Early stopping patience.")
parser.add_argument("--epochs", type=int, default=100, help="train epochs.")

# forecasting task
parser.add_argument('--seq_len', type=int, default=672, help='input sequence length')
parser.add_argument('--label_len', type=int, default=576, help='label length')
parser.add_argument('--token_len', type=int, default=40000, help='token length')
parser.add_argument('--test_seq_len', type=int, default=672, help='test seq len')
parser.add_argument('--test_label_len', type=int, default=576, help='test label len')
parser.add_argument('--test_pred_len', type=int, default=96, help='test pred len')
parser.add_argument('--seasonal_patterns', type=str, default='Monthly', help='subset for M4')

# model define
parser.add_argument('--dropout', type=float, default=0.1, help='dropout')
parser.add_argument('--llm_ckp_dir', type=str, default='./LLM/gpt2', help='llm checkpoints dir')
parser.add_argument('--mlp_hidden_dim', type=int, default=256, help='mlp hidden dim')
parser.add_argument('--mlp_hidden_layers', type=int, default=2, help='mlp hidden layers')
parser.add_argument('--mlp_activation', type=str, default='tanh', help='mlp activation')

# parser.add_argument('--unit_nums', type=int, default = 64)

parser.add_argument('--stage', type=int, default=1, help='training stage')
