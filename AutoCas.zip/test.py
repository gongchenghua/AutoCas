import pickle
import time
import torch
import torch.nn as nn
import torch.nn.functional as F
import time

from torch.utils.data import DataLoader,Dataset

from utils.tools import *
from utils.EarlyStopping import *

from utils.parsers import parser
import os


from utils.AutoTimes_Gpt2_prompt import *


os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
args = parser.parse_args()
device = torch.device("cuda:5")

seed = 2022
if torch.cuda.is_available():
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
torch.manual_seed(seed)

# def MAPE_loss(pred, target):
#     # Prevent division by zero
#     return torch.mean(torch.abs((target - pred) / (target + 1e-8)))

# python run_model.py --input=./dataset/twitter/
def main():

    data_start_time = time.time()

    #####load data
    with open(args.input + 'train.pkl', 'rb') as ftrain:
        train_cascade, train_global, train_label = pickle.load(ftrain)
    with open(args.input + 'val.pkl', 'rb') as fval:
        val_cascade, val_global, val_label = pickle.load(fval)
    with open(args.input + 'test.pkl', 'rb') as ftest:
        test_cascade, test_global, test_label = pickle.load(ftest)

    train_generator = MyDataset(train_cascade, train_global, train_label, args.max_seq)
    val_generator = MyDataset(val_cascade, val_global, val_label, args.max_seq)
    test_generator = MyDataset(test_cascade, test_global, test_label, args.max_seq)

    train_loader = DataLoader(train_generator, batch_size=args.b_size, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_generator, batch_size=args.b_size, num_workers=2)
    test_loader = DataLoader(test_generator, batch_size=args.b_size, num_workers=2)

    data_end_time = time.time()
    print('data loading Finished! Time used: {:.3f}mins.'.format((data_end_time - data_start_time) / 60))

    ## model
    model = Model(args) 
#     model = ODE_diffusion_LODE(args, device)
    ####diffusuon model
#     diff_model = Diffusion(args, device)
#     diff_model = diff_model.to(device)
#     diff_optimizer = torch.optim.Adam(diff_model.parameters(), lr=args.diff_lr)

    model = model.to(device)
    # model初始化完成
    
    optimizer = torch.optim.Adam(model.parameters(), lr = args.lr)
    ##loss
    MSLE_loss = MSLELoss()
    MAPE_loss = MAPELoss()
    MSE_loss = torch.nn.MSELoss()
    # norm = nn.BatchNorm1d(args.max_seq).to(device)
    # norm = nn.BatchNorm1d(args.unit_nums - 1).to(device)
    ##early_stopping
    early_stopping = EarlyStopping(patience=args.patience, verbose=True)

    start_time = time.time()

    model_dict = torch.load("./checkpoint/checkpoint_weibo_1h.pt")
    model.load_state_dict(model_dict)
    print('Finished loading checkpoint!')
    # model test
    model.eval()
    total = 0
    MSLE_test = 0
    MAPE_test = 0
    with torch.no_grad():
        for step, (emb_input, emb_output, labels, cas_time) in enumerate(test_loader):
            cas_time = cas_time.to(torch.float32)

            emb_input = emb_input.to(torch.float32) # [B,23,500,80]
            B, N, _, _ = emb_input.shape
        #     print("input:",input.shape) 
            emb_output = emb_output.to(torch.float32) 

            emb_input, emb_output, labels, cas_time = emb_input.to(device), emb_output.to(device), labels.to(device), cas_time.to(device)

            emb_input = emb_input.reshape(B,N,-1) # [B,23,40000]
            # emb_input = norm(emb_input) # [B,23,500,80]

            test_input = torch.unsqueeze(emb_input[:,0,:], dim = 1) # [B,1,40000]
            # test_input = emb_input[:,0:5,:]
            # print('test_input',test_input)
            test_label = torch.unsqueeze(labels[:,-1], dim = 1) # [B,1]
            # print('test_label',test_label)

            time_unit = args.observation_time 
            unit_nums = args.prediction_time // time_unit
            # 要进行次循环预测
           
            for i in range(1, unit_nums): 
                prompt = (
                        f"<|start_prompt|>Data description: This is a {i} steps series"
                        f"Task description: Forecast the next {i} steps given the previous {i} steps information, and we want to predict the cascade size at final time.<|end_prompt|>"
                )
                outputs, pop = model(test_input, None, prompt)
                # outputs, pop = model(test_input, None)
                print(pop)
                outputs = outputs.reshape(B, i, -1) 
                # print(outputs.shape)
                result = torch.unsqueeze(outputs[:,-1,:], dim=1) # [B,1,40000]
                test_input = torch.cat((test_input, result), dim = 1)

            pop = torch.unsqueeze(pop[:,-1], dim = 1)
            MSLE = MSLE_loss(pop, test_label)
            MAPE = MAPE_loss(pop, test_label)

            total += labels.size(0)
            MSLE_test += MSLE * labels.size(0)
            MAPE_test += MAPE * labels.size(0)

    aver_MSLE = MSLE_test / total
    aver_MAPE = MAPE_test / total
    print("========================")
    print("MSLE_loss:", aver_MSLE)
    print("MAPE_loss:", aver_MAPE)
    print('Finished! Time used: {:.3f}mins.'.format((time.time() - start_time) / 60))

if __name__ == '__main__':
    main()
